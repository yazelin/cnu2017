﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class example2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Debug.Log ("睡不著覺來數羊");
		//從第1隻開始數，要數到1000隻
		for (int 第幾 = 1; 第幾 < 1000; 第幾++) {

			Debug.Log (第幾 + "隻羊");//現在數到第幾隻

			//數到300隻就睡著了
			if (第幾 == 300) {

				Debug.Log ("zzzZZZ");// zzzZZZ 睡著了
				break;	//已經睡著就不再數了
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
