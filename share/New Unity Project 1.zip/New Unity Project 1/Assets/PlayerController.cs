﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		//如果按下鍵盤W鍵
		if (Input.GetKey(KeyCode.W)) {
			gameObject.transform.Translate (0,0,.1f);//向z軸移動
		}
		//如果按下鍵盤S鍵
		if (Input.GetKey(KeyCode.S)) {
			gameObject.transform.Translate (0,0,-.1f);//向z軸移動
		}
		//如果按下鍵盤D鍵
		if (Input.GetKey(KeyCode.D)) {
			gameObject.transform.Translate (.1f,0,0);//向x軸移動
		}
		//如果按下鍵盤A鍵
		if (Input.GetKey(KeyCode.A)) {
			gameObject.transform.Translate (-.1f,0,0);//向x軸移動
		}

		//如果按下鍵盤E鍵
//		if (Input.GetKey(KeyCode.E)) {
//			gameObject.transform.Rotate (0,5,0);//y軸
//		}
		//如果按下鍵盤Q鍵
//		if (Input.GetKey(KeyCode.Q)) {
//			gameObject.transform.Rotate (0,-5,0);//y軸
//		}
		//gameObject.transform.Translate (1,0,0);

		//gameObject.transform.Rotate (10,0,0);


		//用滑鼠控制旋轉
		gameObject.transform.Rotate(0,Input.GetAxis("Mouse X")*10,0);


	}
}
