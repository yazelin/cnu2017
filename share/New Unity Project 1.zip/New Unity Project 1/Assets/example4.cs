﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class example4 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnGUI (){
		//如果GUI上的按鈕被按下
		//這個按鈕在X10,Y10的地方,寬200,高30,上面寫著X ++的字
		if (GUI.Button(new Rect(10,10,200,30),"X ++")) {
			//讓物件以X軸旋轉10度
			gameObject.transform.Rotate (10,0,0);
		}
		if (GUI.Button(new Rect(210,10,200,30),"X --")) {
			gameObject.transform.Rotate (-10,0,0);
		}

		if (GUI.Button(new Rect(10,40,200,30),"Y ++")) {
			gameObject.transform.Rotate (0,10,0);
		}
		if (GUI.Button(new Rect(210,40,200,30),"Y --")) {
			gameObject.transform.Rotate (0,-10,0);
		}

		if (GUI.Button(new Rect(10,70,200,30),"Z ++")) {
			gameObject.transform.Rotate (0,0,10);
		}
		if (GUI.Button(new Rect(210,70,200,30),"Z --")) {
			gameObject.transform.Rotate (0,0,-10);
		}
	}


}
