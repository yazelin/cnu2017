﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class example3 : MonoBehaviour {

	//public GameObject Target;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnGUI (){
		//如果GUI上的按鈕被按下
		//這個按鈕在X10,Y10的地方,寬200,高30,上面寫著X ++的字
		if (GUI.Button(new Rect(10,10,200,30),"X ++")) {
			//讓物件向X軸移動1單位
			gameObject.transform.Translate (1,0,0);
		}
		if (GUI.Button(new Rect(210,10,200,30),"X --")) {
			gameObject.transform.Translate (-1,0,0);
		}
	}
}
